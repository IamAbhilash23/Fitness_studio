# virtual env creation and command to run
python -m venv venv
venv\Scripts\activate
# to install dependencies
pip install -r requirements.txt
# Apply migrations
python manage.py makemigrations
python manage.py migrate
# provide sample classes data directly to sqlite
python manage.py seeds
# run the server
python manage.py runserver
# API Endpoints
# Returns a list of all upcoming fitness classes run the below in the browser
http://127.0.0.1:8000/classes
# Inorder to Book a spot in a fitness class.
http://127.0.0.1:8000/book 
{
  "class_id": "Any class_id from the above classes list",
  "client_name": "Any",
  "client_email": "Any valid mail-id"
}
# Retrieve all bookings made by the specified email.
http://127.0.0.1:8000/bookings?email=sahithi@gmail.com
# for running unittest
python manage.py test booking








