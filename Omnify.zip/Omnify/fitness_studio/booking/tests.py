from django.test import TestCase
from booking.models import FitnessClass, Booking
from django.utils.timezone import make_aware
from datetime import datetime, timedelta
from rest_framework.test import APIClient

class BookingAPITests(TestCase):
    def setUp(self):
        self.client = APIClient()
        dt = make_aware(datetime.now() + timedelta(days=1))
        self.fclass = FitnessClass.objects.create(
            name='Yoga', date_time=dt, instructor='Alice',
            total_slots=5, available_slots=5
        )

    def test_get_classes(self):
        response = self.client.get('/classes')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.data), 1)

    def test_successful_booking(self):
        response = self.client.post('/book', {
            "class_id": self.fclass.id,
            "client_name": "Test User",
            "client_email": "test@example.com"
        }, format='json')
        self.assertEqual(response.status_code, 201)
        self.fclass.refresh_from_db()
        self.assertEqual(self.fclass.available_slots, 4)

    def test_overbooking(self):
        self.fclass.available_slots = 0
        self.fclass.save()
        response = self.client.post('/book', {
            "class_id": self.fclass.id,
            "client_name": "Test User",
            "client_email": "test@example.com"
        }, format='json')
        self.assertEqual(response.status_code, 400)
        self.assertIn('No available slots', response.data['error'])

    def test_missing_fields(self):
        response = self.client.post('/book', {
            "class_id": self.fclass.id
        }, format='json')
        self.assertEqual(response.status_code, 400)

