from django.core.management.base import BaseCommand
from booking.models import FitnessClass
from django.utils.timezone import make_aware
from datetime import datetime, timedelta
import pytz

class Command(BaseCommand):
    help = 'Seeds database with fitness classes'

    def handle(self, *args, **kwargs):
        FitnessClass.objects.all().delete()
        now = datetime.now()
        classes = [
            ('Yoga', now + timedelta(days=1, hours=9), 'Abhilash', 10),
            ('Zumba', now + timedelta(days=1, hours=11), 'Sunny', 15),
            ('HIIT', now + timedelta(days=2, hours=8), 'Pinky', 8),
        ]
        for name, dt, instructor, slots in classes:
            FitnessClass.objects.create(
                name=name, date_time=make_aware(dt), instructor=instructor,
                total_slots=slots, available_slots=slots
            )
        self.stdout.write(self.style.SUCCESS("Seeded sample classes."))
